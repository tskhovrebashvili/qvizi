from flask import Flask, redirect, render_template, request, abort, url_for
import requests

app = Flask(__name__)

@app.route('/home')
@app.route('/rugby')
def rugby():
    url = "https://v1.rugby.api-sports.io"
    api_key = "5529834542eaf3825d46b23526e1c4b7"

    headers = {
        "x-rapidapi-key": api_key,
        "x-rapidapi-host": "v1.rugby.api-sports.io"
    }

    endpoint = "/leagues"
    response = requests.get(url + endpoint, headers=headers)

    if response.status_code != 200:
        abort(response.status_code)

    leagues = response.json().get('response', [])

    endpoint = "/fixtures"
    params = {
        "league": 1,
        "season": 2023
    }
    response = requests.get(url + endpoint, headers=headers, params=params)

    if response.status_code != 200:
        abort(response.status_code)

    fixtures = response.json().get('response', [])

    return render_template('rugby.html', leagues=leagues, fixtures=fixtures)

@app.route('/baseball')
def baseball():
    url = "https://v1.baseball.api-sports.io"
    api_key = "5529834542eaf3825d46b23526e1c4b7"

    headers = {
        "x-rapidapi-key": api_key,
        "x-rapidapi-host": "v1.baseball.api-sports.io"
    }

    endpoint = "/leagues"
    response = requests.get(url + endpoint, headers=headers)

    if response.status_code != 200:
        abort(response.status_code)

    leagues = response.json().get('response', [])

    endpoint = "/games"
    params = {
        "league": 1,
        "season": 2023
    }
    response = requests.get(url + endpoint, headers=headers, params=params)

    if response.status_code != 200:
        abort(response.status_code)

    fixtures = response.json().get('response', [])

    return render_template('baseball.html', leagues=leagues, fixtures=fixtures)

@app.route('/football')
def football():
    url = "https://v3.football.api-sports.io"
    api_key = "5529834542eaf3825d46b23526e1c4b7"

    headers = {
        "x-rapidapi-key": api_key,
        "x-rapidapi-host": "v3.football.api-sports.io"
    }


    endpoint = "/leagues"
    response = requests.get(url + endpoint, headers=headers)

    if response.status_code != 200:
        abort(response.status_code)

    leagues = response.json().get('response', [])


    endpoint = "/fixtures"
    params = {
        "league": 39,
        "season": 2023
    }
    response = requests.get(url + endpoint, headers=headers, params=params)

    if response.status_code != 200:
        abort(response.status_code)

    fixtures = response.json().get('response', [])

    return render_template('football.html', leagues=leagues, fixtures=fixtures)

@app.route('/basketball')
def basketball():
    url = "https://v1.basketball.api-sports.io"
    api_key = "5529834542eaf3825d46b23526e1c4b7"

    headers = {
        "x-rapidapi-key": api_key,
        "x-rapidapi-host": "v1.basketball.api-sports.io"
    }

    endpoint = "/leagues"
    response = requests.get(url + endpoint, headers=headers)

    if response.status_code != 200:
        abort(response.status_code)

    leagues = response.json().get('response', [])

    endpoint = "/games"
    params = {
        "league": 12,
        "season": 2023
    }
    response = requests.get(url + endpoint, headers=headers, params=params)

    if response.status_code != 200:
        abort(response.status_code)

    fixtures = response.json().get('response', [])

    return render_template('basketball.html', leagues=leagues, fixtures=fixtures)

@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == 'POST':
        return 'თქვენ წარმატებით გაიარეთ ავტორიზაცია'
    return render_template('login.html')

if __name__ == '__main__':
    app.run(debug=True)